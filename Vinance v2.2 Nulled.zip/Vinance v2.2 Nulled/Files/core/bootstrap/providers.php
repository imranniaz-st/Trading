<?php

return [
    App\Providers\AppServiceProvider::class,
    Illuminate\Broadcasting\BroadcastServiceProvider::class,
];
